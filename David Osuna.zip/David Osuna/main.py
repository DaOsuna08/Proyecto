
from validation import valInt as vInt
from validation import valFloat as vFloat
from validation import valComplex as vComplex
from validation import valList as vList

from crypto import cif as cifrar
from crypto import decif as decifrar

from algebra import mulmat as multiplicacion
from algebra import invmatriz as inversion
from algebra import trasmatriz as transposicion
from algebra import determatriz as determinante
from algebra import eclin as ec_lineales